<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import AuthLayout from '../components/layouts/AuthLayout.vue'

const router = useRouter()
const fullName = ref('')
const email = ref('')
const password = ref('')
const confirmPassword = ref('')
const isLoading = ref(false)
const errorMessage = ref('')

const register = () => {
  errorMessage.value = ''
  
  if (!fullName.value || !email.value || !password.value) {
    errorMessage.value = '请填写所有必填项'
    return
  }
  
  if (password.value !== confirmPassword.value) {
    errorMessage.value = '两次输入的密码不一致'
    return
  }
  
  if (password.value.length < 8) {
    errorMessage.value = '密码长度至少为8位'
    return
  }
  
  isLoading.value = true
  
  setTimeout(() => {
    isLoading.value = false
    
    if (email.value === 'existing@example.com') {
      errorMessage.value = '该邮箱已被注册'
      return
    }
    
    router.push('/login')
  }, 1000)
}

const goToLogin = () => {
  router.push('/login')
}
</script>

<template>
  <AuthLayout>
    <div class="register-container">
      <div class="auth-header">
        <h1>创建账号</h1>
        <p>注册 Vue Mail 开始使用</p>
      </div>
      
      <div v-if="errorMessage" class="error-message">
        {{ errorMessage }}
      </div>
      
      <form @submit.prevent="register" class="auth-form">
        <div class="form-group">
          <label for="fullName" class="form-label">姓名</label>
          <input
            id="fullName"
            v-model="fullName"
            type="text"
            class="form-input"
            placeholder="张三"
            required
          />
        </div>
        
        <div class="form-group">
          <label for="email" class="form-label">邮箱地址</label>
          <input
            id="email"
            v-model="email"
            type="email"
            class="form-input"
            placeholder="name@example.com"
            required
          />
        </div>
        
        <div class="form-group">
          <label for="password" class="form-label">密码</label>
          <input
            id="password"
            v-model="password"
            type="password"
            class="form-input"
            placeholder="••••••••"
            required
          />
        </div>
        
        <div class="form-group">
          <label for="confirmPassword" class="form-label">确认密码</label>
          <input
            id="confirmPassword"
            v-model="confirmPassword"
            type="password"
            class="form-input"
            placeholder="••••••••"
            required
          />
        </div>
        
        <button
          type="submit"
          class="btn btn-primary w-full"
          :disabled="isLoading"
        >
          <font-awesome-icon
            v-if="isLoading"
            icon="spinner"
            spin
            class="mr-2"
          />
          创建账号
        </button>
      </form>
      
      <div class="auth-footer">
        <p>已有账号？ <a href="#" @click.prevent="goToLogin">登录</a></p>
      </div>
    </div>
  </AuthLayout>
</template>

<style scoped>
.register-container {
  width: 100%;
  max-width: 400px;
}

.auth-header {
  text-align: center;
  margin-bottom: var(--space-6);
}

.auth-header h1 {
  color: var(--color-primary-700);
  margin-bottom: var(--space-2);
}

.auth-header p {
  color: var(--color-gray-600);
}

.auth-form {
  background-color: white;
  padding: var(--space-6);
  border-radius: var(--border-radius-lg);
  box-shadow: var(--shadow-md);
}

.error-message {
  background-color: rgba(239, 68, 68, 0.1);
  color: var(--color-error-500);
  padding: var(--space-3);
  border-radius: var(--border-radius);
  margin-bottom: var(--space-4);
  font-size: var(--text-sm);
}

.auth-footer {
  text-align: center;
  margin-top: var(--space-4);
  font-size: var(--text-sm);
  color: var(--color-gray-600);
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.register-container {
  animation: fadeIn 0.5s ease-out;
}
</style>