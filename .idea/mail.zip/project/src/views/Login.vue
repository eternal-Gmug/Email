<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import AuthLayout from '../components/layouts/AuthLayout.vue'

const router = useRouter()
const email = ref('')
const password = ref('')
const rememberMe = ref(false)
const isLoading = ref(false)
const errorMessage = ref('')

const login = () => {
  errorMessage.value = ''
  
  if (!email.value || !password.value) {
    errorMessage.value = '请输入邮箱和密码'
    return
  }
  
  isLoading.value = true
  
  setTimeout(() => {
    isLoading.value = false
    
    if (email.value === 'wrong@example.com') {
      errorMessage.value = '邮箱或密码错误'
      return
    }
    
    router.push('/dashboard/inbox')
  }, 1000)
}

const goToRegister = () => {
  router.push('/register')
}
</script>

<template>
  <AuthLayout>
    <div class="login-container">
      <div class="auth-header">
        <h1>欢迎使用 Vue Mail</h1>
        <p>登录以继续使用邮箱</p>
      </div>
      
      <div v-if="errorMessage" class="error-message">
        {{ errorMessage }}
      </div>
      
      <form @submit.prevent="login" class="auth-form">
        <div class="form-group">
          <label for="email" class="form-label">邮箱地址</label>
          <input
            id="email"
            v-model="email"
            type="email"
            class="form-input"
            placeholder="name@example.com"
            required
          />
        </div>
        
        <div class="form-group">
          <label for="password" class="form-label">密码</label>
          <input
            id="password"
            v-model="password"
            type="password"
            class="form-input"
            placeholder="••••••••"
            required
          />
        </div>
        
        <div class="form-options">
          <div class="remember-me">
            <input
              id="remember-me"
              v-model="rememberMe"
              type="checkbox"
            />
            <label for="remember-me">记住我</label>
          </div>
          
          <a href="#" class="forgot-password">忘记密码？</a>
        </div>
        
        <button
          type="submit"
          class="btn btn-primary w-full"
          :disabled="isLoading"
        >
          <font-awesome-icon
            v-if="isLoading"
            icon="spinner"
            spin
            class="mr-2"
          />
          登录
        </button>
      </form>
      
      <div class="auth-footer">
        <p>还没有账号？ <a href="#" @click.prevent="goToRegister">注册</a></p>
      </div>
    </div>
  </AuthLayout>
</template>

<style scoped>
.login-container {
  width: 100%;
  max-width: 400px;
}

.auth-header {
  text-align: center;
  margin-bottom: var(--space-6);
}

.auth-header h1 {
  color: var(--color-primary-700);
  margin-bottom: var(--space-2);
}

.auth-header p {
  color: var(--color-gray-600);
}

.auth-form {
  background-color: white;
  padding: var(--space-6);
  border-radius: var(--border-radius-lg);
  box-shadow: var(--shadow-md);
}

.form-options {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: var(--space-4);
  font-size: var(--text-sm);
}

.remember-me {
  display: flex;
  align-items: center;
  gap: var(--space-2);
}

.forgot-password {
  color: var(--color-primary-600);
}

.error-message {
  background-color: rgba(239, 68, 68, 0.1);
  color: var(--color-error-500);
  padding: var(--space-3);
  border-radius: var(--border-radius);
  margin-bottom: var(--space-4);
  font-size: var(--text-sm);
}

.auth-footer {
  text-align: center;
  margin-top: var(--space-4);
  font-size: var(--text-sm);
  color: var(--color-gray-600);
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.login-container {
  animation: fadeIn 0.5s ease-out;
}
</style>