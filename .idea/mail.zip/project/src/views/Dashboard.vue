<script setup lang="ts">
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'
import Sidebar from '../components/navigation/Sidebar.vue'
import Header from '../components/navigation/Header.vue'

const router = useRouter()
const isSidebarOpen = ref(true)

const toggleSidebar = () => {
  isSidebarOpen.value = !isSidebarOpen.value
}

const mainClass = computed(() => {
  return {
    'main-content': true,
    'sidebar-closed': !isSidebarOpen.value
  }
})
</script>

<template>
  <div class="dashboard-layout">
    <Sidebar :is-open="isSidebarOpen" />
    
    <div :class="mainClass">
      <Header @toggle-sidebar="toggleSidebar" />
      
      <main class="content-area">
        <router-view v-slot="{ Component }">
          <transition name="fade" mode="out-in">
            <component :is="Component" />
          </transition>
        </router-view>
      </main>
    </div>
  </div>
</template>

<style scoped>
.dashboard-layout {
  display: flex;
  height: 100vh;
  overflow: hidden;
}

.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  transition: margin-left 0.3s ease;
}

.content-area {
  flex: 1;
  overflow: auto;
  background-color: var(--color-gray-100);
  padding: var(--space-4);
}

@media (max-width: 768px) {
  .main-content {
    margin-left: 0 !important;
    width: 100%;
  }
}
</style>