<script setup lang="ts">
import { ref } from 'vue'

const activeTab = ref('account')

const user = ref({
  name: 'John Doe',
  email: 'john.doe@example.com',
  signature: '<p>Best regards,<br>John Doe</p>',
  avatar: ''
})

const preferences = ref({
  showNotifications: true,
  emailsPerPage: 20,
  autoSaveDrafts: true,
  language: 'en',
  theme: 'light'
})

const security = ref({
  twoFactorEnabled: false,
  lastPasswordChange: '2024-12-15',
  connectedDevices: [
    { name: 'MacBook Pro', lastActive: '2025-01-10T14:32:45' },
    { name: 'iPhone 15', lastActive: '2025-01-10T17:15:22' }
  ]
})

const switchTab = (tab: string) => {
  activeTab.value = tab
}

const updateProfile = () => {
  console.log('Profile updated')
  // Show success message
}

const updatePreferences = () => {
  console.log('Preferences updated')
  // Show success message
}

const enableTwoFactor = () => {
  security.value.twoFactorEnabled = true
  // In a real app, this would trigger a setup flow
}

const disableTwoFactor = () => {
  security.value.twoFactorEnabled = false
  // In a real app, this would require confirmation
}

const formatDate = (dateString: string): string => {
  const date = new Date(dateString)
  return date.toLocaleDateString()
}

const formatDateTime = (dateTimeString: string): string => {
  const date = new Date(dateTimeString)
  return date.toLocaleString()
}
</script>

<template>
  <div class="settings-container">
    <div class="settings-header">
      <h1>Settings</h1>
      <p>Manage your account settings and preferences</p>
    </div>
    
    <div class="settings-content">
      <div class="settings-sidebar">
        <button
          :class="['tab-btn', { 'active': activeTab === 'account' }]"
          @click="switchTab('account')"
        >
          <font-awesome-icon icon="user" class="tab-icon" />
          Account
        </button>
        <button
          :class="['tab-btn', { 'active': activeTab === 'preferences' }]"
          @click="switchTab('preferences')"
        >
          <font-awesome-icon icon="cog" class="tab-icon" />
          Preferences
        </button>
        <button
          :class="['tab-btn', { 'active': activeTab === 'security' }]"
          @click="switchTab('security')"
        >
          <font-awesome-icon icon="lock" class="tab-icon" />
          Security
        </button>
      </div>
      
      <div class="settings-panel">
        <!-- Account Settings -->
        <div v-if="activeTab === 'account'" class="tab-content">
          <h2>Account Settings</h2>
          
          <div class="form-section">
            <div class="form-group">
              <label for="name" class="form-label">Full Name</label>
              <input
                id="name"
                v-model="user.name"
                type="text"
                class="form-input"
              />
            </div>
            
            <div class="form-group">
              <label for="email" class="form-label">Email Address</label>
              <input
                id="email"
                v-model="user.email"
                type="email"
                class="form-input"
                disabled
              />
              <div class="help-text">Contact support to change your email address</div>
            </div>
            
            <div class="form-group">
              <label for="signature" class="form-label">Email Signature</label>
              <textarea
                id="signature"
                v-model="user.signature"
                class="form-input"
                rows="4"
              ></textarea>
              <div class="help-text">HTML formatting is supported</div>
            </div>
            
            <div class="form-actions">
              <button class="btn btn-primary" @click="updateProfile">
                Save Changes
              </button>
            </div>
          </div>
        </div>
        
        <!-- Preferences Settings -->
        <div v-if="activeTab === 'preferences'" class="tab-content">
          <h2>Preferences</h2>
          
          <div class="form-section">
            <div class="form-group checkbox-group">
              <input
                id="notifications"
                v-model="preferences.showNotifications"
                type="checkbox"
              />
              <label for="notifications">Show desktop notifications</label>
            </div>
            
            <div class="form-group checkbox-group">
              <input
                id="auto-save"
                v-model="preferences.autoSaveDrafts"
                type="checkbox"
              />
              <label for="auto-save">Auto-save drafts</label>
            </div>
            
            <div class="form-group">
              <label for="emails-per-page" class="form-label">Emails per page</label>
              <select
                id="emails-per-page"
                v-model="preferences.emailsPerPage"
                class="form-select"
              >
                <option value="10">10</option>
                <option value="20">20</option>
                <option value="50">50</option>
                <option value="100">100</option>
              </select>
            </div>
            
            <div class="form-group">
              <label for="language" class="form-label">Language</label>
              <select
                id="language"
                v-model="preferences.language"
                class="form-select"
              >
                <option value="en">English</option>
                <option value="fr">Français</option>
                <option value="es">Español</option>
                <option value="de">Deutsch</option>
              </select>
            </div>
            
            <div class="form-group">
              <label for="theme" class="form-label">Theme</label>
              <select
                id="theme"
                v-model="preferences.theme"
                class="form-select"
              >
                <option value="light">Light</option>
                <option value="dark">Dark</option>
                <option value="system">System Default</option>
              </select>
            </div>
            
            <div class="form-actions">
              <button class="btn btn-primary" @click="updatePreferences">
                Save Preferences
              </button>
            </div>
          </div>
        </div>
        
        <!-- Security Settings -->
        <div v-if="activeTab === 'security'" class="tab-content">
          <h2>Security</h2>
          
          <div class="form-section">
            <h3>Two-Factor Authentication</h3>
            <p class="mb-4">
              Add an extra layer of security to your account by enabling two-factor authentication.
            </p>
            
            <div v-if="security.twoFactorEnabled" class="status-box success">
              <font-awesome-icon icon="check-circle" class="status-icon" />
              <div>
                <strong>Two-factor authentication is enabled</strong>
                <p>Your account has an extra layer of security.</p>
              </div>
              <button class="btn btn-secondary" @click="disableTwoFactor">
                Disable
              </button>
            </div>
            
            <div v-else class="status-box warning">
              <font-awesome-icon icon="exclamation-circle" class="status-icon" />
              <div>
                <strong>Two-factor authentication is not enabled</strong>
                <p>Protect your account with an extra layer of security.</p>
              </div>
              <button class="btn btn-primary" @click="enableTwoFactor">
                Enable
              </button>
            </div>
            
            <div class="divider"></div>
            
            <h3>Password</h3>
            <p>
              Last changed: {{ formatDate(security.lastPasswordChange) }}
            </p>
            <button class="btn btn-secondary mt-2">
              Change Password
            </button>
            
            <div class="divider"></div>
            
            <h3>Connected Devices</h3>
            <p class="mb-4">
              These devices have logged into your account recently.
            </p>
            
            <div v-for="(device, index) in security.connectedDevices" :key="index" class="device-item">
              <div>
                <strong>{{ device.name }}</strong>
                <p class="device-last-active">
                  Last active: {{ formatDateTime(device.lastActive) }}
                </p>
              </div>
              <button class="btn btn-sm btn-secondary">
                Logout
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.settings-container {
  background-color: white;
  border-radius: var(--border-radius-lg);
  box-shadow: var(--shadow);
  height: calc(100vh - 140px);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.settings-header {
  padding: var(--space-4) var(--space-6);
  border-bottom: 1px solid var(--color-gray-200);
}

.settings-header h1 {
  font-size: var(--text-2xl);
  margin-bottom: var(--space-1);
  color: var(--color-gray-900);
}

.settings-header p {
  color: var(--color-gray-600);
  margin: 0;
}

.settings-content {
  flex: 1;
  display: flex;
  overflow: hidden;
}

.settings-sidebar {
  width: 200px;
  border-right: 1px solid var(--color-gray-200);
  padding: var(--space-4);
}

.tab-btn {
  display: flex;
  align-items: center;
  width: 100%;
  padding: var(--space-3) var(--space-4);
  border: none;
  background: none;
  text-align: left;
  font-weight: 500;
  border-radius: var(--border-radius);
  margin-bottom: var(--space-1);
  color: var(--color-gray-700);
  cursor: pointer;
  transition: all 0.2s;
}

.tab-btn:hover {
  background-color: var(--color-gray-100);
  color: var(--color-gray-900);
}

.tab-btn.active {
  background-color: var(--color-primary-50);
  color: var(--color-primary-700);
}

.tab-icon {
  margin-right: var(--space-3);
  width: 16px;
}

.settings-panel {
  flex: 1;
  padding: var(--space-6);
  overflow: auto;
}

.tab-content h2 {
  margin-bottom: var(--space-6);
  color: var(--color-gray-900);
  font-size: var(--text-xl);
}

.form-section {
  max-width: 600px;
}

.form-group {
  margin-bottom: var(--space-4);
}

.checkbox-group {
  display: flex;
  align-items: center;
  gap: var(--space-2);
}

.form-select {
  width: 100%;
  padding: var(--space-2) var(--space-3);
  border: 1px solid var(--color-gray-300);
  border-radius: var(--border-radius);
  font-size: var(--text-base);
  transition: border-color 0.2s;
}

.form-select:focus {
  outline: none;
  border-color: var(--color-primary-500);
  box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
}

.help-text {
  margin-top: var(--space-1);
  font-size: var(--text-sm);
  color: var(--color-gray-500);
}

.form-actions {
  margin-top: var(--space-6);
}

.divider {
  height: 1px;
  background-color: var(--color-gray-200);
  margin: var(--space-6) 0;
}

h3 {
  font-size: var(--text-lg);
  margin-bottom: var(--space-3);
  color: var(--color-gray-800);
}

.status-box {
  display: flex;
  align-items: center;
  padding: var(--space-4);
  border-radius: var(--border-radius);
  margin-bottom: var(--space-4);
}

.status-box.success {
  background-color: rgba(34, 197, 94, 0.1);
  color: var(--color-success-500);
}

.status-box.warning {
  background-color: rgba(245, 158, 11, 0.1);
  color: var(--color-warning-500);
}

.status-box div {
  flex: 1;
}

.status-box p {
  margin: var(--space-1) 0 0;
  color: var(--color-gray-700);
}

.status-icon {
  font-size: 1.5rem;
  margin-right: var(--space-4);
}

.device-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: var(--space-3) 0;
  border-bottom: 1px solid var(--color-gray-200);
}

.device-item:last-child {
  border-bottom: none;
}

.device-last-active {
  font-size: var(--text-sm);
  color: var(--color-gray-500);
  margin: 0;
}

.mb-4 {
  margin-bottom: var(--space-4);
}

.mt-2 {
  margin-top: var(--space-2);
}

/* Animation */
.tab-content {
  animation: fadeIn 0.3s ease-out;
}

@keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
</style>