<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { emails } from '../data/emails'
import type { Email } from '../data/emails'

const route = useRoute()
const router = useRouter()

const email = ref<Email | null>(null)
const loading = ref(true)
const showReplyForm = ref(false)
const replyContent = ref('')

const emailId = computed(() => {
  return Number(route.params.id)
})

const formattedDate = computed(() => {
  if (!email.value) return ''
  
  const date = new Date(email.value.date)
  return date.toLocaleString([], {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  })
})

const loadEmail = () => {
  loading.value = true
  
  // In a real app, we would fetch the email from the server
  // For now, we'll just simulate it with a timeout
  setTimeout(() => {
    const foundEmail = emails.find(e => e.id === emailId.value)
    
    if (foundEmail) {
      email.value = { ...foundEmail, read: true }
    } else {
      // Handle not found
      router.push('/dashboard/inbox')
    }
    
    loading.value = false
  }, 600)
}

const goBack = () => {
  router.push('/dashboard/inbox')
}

const toggleReplyForm = () => {
  showReplyForm.value = !showReplyForm.value
  if (showReplyForm.value) {
    replyContent.value = ''
  }
}

const sendReply = () => {
  if (!replyContent.value.trim()) {
    return
  }
  
  // In a real app, we would send the reply to the server
  // For now, we'll just simulate it
  console.log('Sending reply:', replyContent.value)
  
  // Close the reply form and reset content
  showReplyForm.value = false
  replyContent.value = ''
  
  // Show a success message or notification here
}

onMounted(() => {
  loadEmail()
})
</script>

<template>
  <div class="email-view-container">
    <div class="email-view-header">
      <button class="back-btn" @click="goBack">
        <font-awesome-icon icon="chevron-left" />
        <span>Back to Inbox</span>
      </button>
      
      <div class="email-actions" v-if="email">
        <button class="btn btn-icon" title="Archive">
          <font-awesome-icon icon="archive" />
        </button>
        <button class="btn btn-icon" title="Delete">
          <font-awesome-icon icon="trash" />
        </button>
        <button class="btn btn-icon" :class="{ 'active': email.starred }" title="Star">
          <font-awesome-icon icon="star" />
        </button>
      </div>
    </div>
    
    <div v-if="loading" class="loading-container">
      <font-awesome-icon icon="spinner" spin class="loading-spinner" />
      <p>Loading email...</p>
    </div>
    
    <div v-else-if="email" class="email-content">
      <div class="email-subject">
        <h1>{{ email.subject }}</h1>
      </div>
      
      <div class="email-meta">
        <div class="sender-info">
          <div class="avatar">
            {{ email.from.name.charAt(0) }}
          </div>
          <div class="sender-details">
            <div class="sender-name">
              {{ email.from.name }}
              <span class="sender-email">&lt;{{ email.from.email }}&gt;</span>
            </div>
            <div class="email-date">{{ formattedDate }}</div>
          </div>
        </div>
        <div class="recipient-info">
          <span class="to-label">To:</span>
          <span v-for="(recipient, index) in email.to" :key="index" class="recipient">
            {{ recipient.name }}
            <span v-if="index < email.to.length - 1">, </span>
          </span>
        </div>
      </div>
      
      <div class="email-body" v-html="email.body"></div>
      
      <div v-if="email.attachments.length > 0" class="email-attachments">
        <h3>Attachments ({{ email.attachments.length }})</h3>
        <div class="attachments-list">
          <div v-for="(attachment, index) in email.attachments" :key="index" class="attachment-item">
            <div class="attachment-icon">
              <font-awesome-icon icon="file" />
            </div>
            <div class="attachment-details">
              <div class="attachment-name">{{ attachment.name }}</div>
              <div class="attachment-size">{{ attachment.size }}</div>
            </div>
            <button class="btn btn-sm">
              Download
            </button>
          </div>
        </div>
      </div>
      
      <div class="email-reply">
        <div class="reply-actions">
          <button class="btn btn-primary" @click="toggleReplyForm">
            <font-awesome-icon icon="reply" class="mr-2" />
            Reply
          </button>
          <button class="btn btn-secondary">
            <font-awesome-icon icon="reply-all" class="mr-2" />
            Reply All
          </button>
          <button class="btn btn-secondary">
            <font-awesome-icon icon="forward" class="mr-2" />
            Forward
          </button>
        </div>
        
        <div v-if="showReplyForm" class="reply-form">
          <h3>Reply to {{ email.from.name }}</h3>
          <textarea
            v-model="replyContent"
            class="reply-textarea"
            placeholder="Write your reply here..."
            rows="6"
          ></textarea>
          <div class="reply-form-actions">
            <button class="btn btn-primary" @click="sendReply" :disabled="!replyContent.trim()">
              Send
            </button>
            <button class="btn btn-secondary" @click="toggleReplyForm">
              Cancel
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.email-view-container {
  background-color: white;
  border-radius: var(--border-radius-lg);
  box-shadow: var(--shadow);
  height: calc(100vh - 140px);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.email-view-header {
  padding: var(--space-4);
  border-bottom: 1px solid var(--color-gray-200);
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.back-btn {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  background: none;
  border: none;
  color: var(--color-gray-600);
  font-weight: 500;
  cursor: pointer;
  padding: var(--space-2) var(--space-3);
  border-radius: var(--border-radius);
  transition: all 0.2s;
}

.back-btn:hover {
  background-color: var(--color-gray-100);
  color: var(--color-gray-900);
}

.email-actions {
  display: flex;
  gap: var(--space-2);
}

.email-actions .btn-icon {
  color: var(--color-gray-600);
  background-color: var(--color-gray-100);
}

.email-actions .btn-icon:hover {
  background-color: var(--color-gray-200);
  color: var(--color-gray-900);
}

.email-actions .btn-icon.active {
  color: var(--color-warning-500);
}

.loading-container {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: var(--color-gray-500);
}

.loading-spinner {
  font-size: 2rem;
  margin-bottom: var(--space-4);
  color: var(--color-primary-500);
}

.email-content {
  flex: 1;
  overflow: auto;
  padding: var(--space-6);
}

.email-subject h1 {
  font-size: var(--text-2xl);
  color: var(--color-gray-900);
  margin-bottom: var(--space-4);
}

.email-meta {
  margin-bottom: var(--space-6);
  border-bottom: 1px solid var(--color-gray-200);
  padding-bottom: var(--space-4);
}

.sender-info {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  margin-bottom: var(--space-3);
}

.avatar {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  background-color: var(--color-primary-100);
  color: var(--color-primary-700);
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 600;
  font-size: var(--text-lg);
}

.sender-details {
  flex: 1;
}

.sender-name {
  font-weight: 600;
  color: var(--color-gray-900);
}

.sender-email {
  color: var(--color-gray-600);
  font-weight: normal;
  margin-left: var(--space-1);
}

.email-date {
  color: var(--color-gray-600);
  font-size: var(--text-sm);
}

.recipient-info {
  color: var(--color-gray-700);
  font-size: var(--text-sm);
}

.to-label {
  color: var(--color-gray-600);
  margin-right: var(--space-1);
}

.email-body {
  color: var(--color-gray-800);
  line-height: 1.6;
  margin-bottom: var(--space-6);
}

.email-attachments {
  margin-bottom: var(--space-6);
  padding: var(--space-4);
  background-color: var(--color-gray-50);
  border-radius: var(--border-radius);
}

.email-attachments h3 {
  margin-bottom: var(--space-3);
  font-size: var(--text-base);
  color: var(--color-gray-700);
}

.attachments-list {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
}

.attachment-item {
  display: flex;
  align-items: center;
  padding: var(--space-2) var(--space-3);
  background-color: white;
  border: 1px solid var(--color-gray-200);
  border-radius: var(--border-radius);
}

.attachment-icon {
  margin-right: var(--space-3);
  color: var(--color-gray-500);
}

.attachment-details {
  flex: 1;
}

.attachment-name {
  font-weight: 500;
  color: var(--color-gray-800);
}

.attachment-size {
  font-size: var(--text-xs);
  color: var(--color-gray-500);
}

.email-reply {
  margin-top: var(--space-6);
}

.reply-actions {
  display: flex;
  gap: var(--space-2);
  margin-bottom: var(--space-4);
}

.reply-form {
  background-color: var(--color-gray-50);
  border-radius: var(--border-radius);
  padding: var(--space-4);
  margin-top: var(--space-4);
}

.reply-form h3 {
  margin-bottom: var(--space-3);
  font-size: var(--text-base);
  color: var(--color-gray-700);
}

.reply-textarea {
  width: 100%;
  border: 1px solid var(--color-gray-300);
  border-radius: var(--border-radius);
  padding: var(--space-3);
  margin-bottom: var(--space-3);
  font-family: inherit;
  font-size: inherit;
  resize: vertical;
}

.reply-textarea:focus {
  outline: none;
  border-color: var(--color-primary-500);
  box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
}

.reply-form-actions {
  display: flex;
  gap: var(--space-2);
  justify-content: flex-end;
}

.mr-2 {
  margin-right: var(--space-2);
}

/* Animation */
.email-content {
  animation: fadeIn 0.4s ease-out;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
</style>