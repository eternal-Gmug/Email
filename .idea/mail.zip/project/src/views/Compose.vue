<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()

const to = ref('')
const cc = ref('')
const bcc = ref('')
const subject = ref('')
const content = ref('')
const attachments = ref<File[]>([])
const showCc = ref(false)
const showBcc = ref(false)
const isSending = ref(false)

const toggleCc = () => {
  showCc.value = !showCc.value
}

const toggleBcc = () => {
  showBcc.value = !showBcc.value
}

const handleFileInput = (event: Event) => {
  const target = event.target as HTMLInputElement
  if (target.files) {
    for (let i = 0; i < target.files.length; i++) {
      attachments.value.push(target.files[i])
    }
  }
}

const removeAttachment = (index: number) => {
  attachments.value.splice(index, 1)
}

const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return '0 Bytes'
  
  const k = 1024
  const sizes = ['Bytes', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
}

const sendEmail = () => {
  // Validate form
  if (!to.value || !subject.value || !content.value) {
    // Show error message
    return
  }
  
  // Show sending indicator
  isSending.value = true
  
  // Simulate sending email
  setTimeout(() => {
    isSending.value = false
    
    // Navigate back to inbox
    router.push('/dashboard/inbox')
    
    // Show success notification (in a real app)
  }, 1500)
}

const cancel = () => {
  router.push('/dashboard/inbox')
}

const saveDraft = () => {
  // Save email as draft
  console.log('Saving draft')
  
  // Navigate back to inbox
  router.push('/dashboard/inbox')
}
</script>

<template>
  <div class="compose-container">
    <div class="compose-header">
      <h1>New Message</h1>
      <div class="compose-actions">
        <button class="btn btn-secondary" @click="saveDraft">
          Save Draft
        </button>
        <button class="btn btn-primary" @click="sendEmail" :disabled="isSending">
          <font-awesome-icon v-if="isSending" icon="spinner" spin class="mr-2" />
          Send
        </button>
      </div>
    </div>
    
    <form @submit.prevent="sendEmail" class="compose-form">
      <div class="compose-fields">
        <div class="form-group">
          <label for="to" class="form-label">To:</label>
          <input
            id="to"
            v-model="to"
            type="text"
            class="form-input"
            placeholder="name@example.com"
            required
          />
        </div>
        
        <div class="compose-options">
          <a href="#" @click.prevent="toggleCc">Cc</a>
          <a href="#" @click.prevent="toggleBcc">Bcc</a>
        </div>
        
        <div v-if="showCc" class="form-group">
          <label for="cc" class="form-label">Cc:</label>
          <input
            id="cc"
            v-model="cc"
            type="text"
            class="form-input"
            placeholder="name@example.com"
          />
        </div>
        
        <div v-if="showBcc" class="form-group">
          <label for="bcc" class="form-label">Bcc:</label>
          <input
            id="bcc"
            v-model="bcc"
            type="text"
            class="form-input"
            placeholder="name@example.com"
          />
        </div>
        
        <div class="form-group">
          <label for="subject" class="form-label">Subject:</label>
          <input
            id="subject"
            v-model="subject"
            type="text"
            class="form-input"
            placeholder="Subject"
            required
          />
        </div>
      </div>
      
      <div class="email-content-editor">
        <textarea
          v-model="content"
          class="content-textarea"
          placeholder="Write your message here..."
          rows="12"
          required
        ></textarea>
      </div>
      
      <div class="attachments-section">
        <div v-if="attachments.length > 0" class="attachments-list">
          <div v-for="(file, index) in attachments" :key="index" class="attachment-item">
            <div class="attachment-icon">
              <font-awesome-icon icon="file" />
            </div>
            <div class="attachment-details">
              <div class="attachment-name">{{ file.name }}</div>
              <div class="attachment-size">{{ formatFileSize(file.size) }}</div>
            </div>
            <button 
              type="button" 
              class="btn btn-icon remove-attachment" 
              @click="removeAttachment(index)"
            >
              <font-awesome-icon icon="times" />
            </button>
          </div>
        </div>
        
        <div class="attachment-actions">
          <label for="file-upload" class="btn btn-secondary">
            <font-awesome-icon icon="paperclip" class="mr-2" />
            Attach Files
          </label>
          <input
            id="file-upload"
            type="file"
            multiple
            class="hidden-input"
            @change="handleFileInput"
          />
        </div>
      </div>
      
      <div class="compose-footer">
        <button type="button" class="btn btn-secondary" @click="cancel">
          Cancel
        </button>
        <button type="submit" class="btn btn-primary" :disabled="isSending">
          <font-awesome-icon v-if="isSending" icon="spinner" spin class="mr-2" />
          Send
        </button>
      </div>
    </form>
  </div>
</template>

<style scoped>
.compose-container {
  background-color: white;
  border-radius: var(--border-radius-lg);
  box-shadow: var(--shadow);
  height: calc(100vh - 140px);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.compose-header {
  padding: var(--space-4);
  border-bottom: 1px solid var(--color-gray-200);
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.compose-header h1 {
  font-size: var(--text-xl);
  margin: 0;
  color: var(--color-gray-800);
}

.compose-actions {
  display: flex;
  gap: var(--space-2);
}

.compose-form {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.compose-fields {
  padding: var(--space-4);
  border-bottom: 1px solid var(--color-gray-200);
}

.compose-options {
  display: flex;
  gap: var(--space-4);
  margin-bottom: var(--space-3);
}

.compose-options a {
  color: var(--color-primary-600);
  font-size: var(--text-sm);
}

.email-content-editor {
  flex: 1;
  padding: var(--space-4);
  overflow: auto;
}

.content-textarea {
  width: 100%;
  height: 100%;
  border: none;
  resize: none;
  font-family: inherit;
  font-size: inherit;
  line-height: 1.6;
}

.content-textarea:focus {
  outline: none;
}

.attachments-section {
  padding: var(--space-4);
  border-top: 1px solid var(--color-gray-200);
}

.attachments-list {
  margin-bottom: var(--space-4);
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-2);
}

.attachment-item {
  display: flex;
  align-items: center;
  padding: var(--space-2) var(--space-3);
  background-color: var(--color-gray-50);
  border: 1px solid var(--color-gray-200);
  border-radius: var(--border-radius);
  max-width: 250px;
}

.attachment-icon {
  margin-right: var(--space-3);
  color: var(--color-gray-500);
}

.attachment-details {
  flex: 1;
  min-width: 0;
}

.attachment-name {
  font-weight: 500;
  color: var(--color-gray-800);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.attachment-size {
  font-size: var(--text-xs);
  color: var(--color-gray-500);
}

.remove-attachment {
  color: var(--color-gray-500);
  background: none;
}

.remove-attachment:hover {
  color: var(--color-error-500);
}

.hidden-input {
  display: none;
}

.compose-footer {
  padding: var(--space-4);
  border-top: 1px solid var(--color-gray-200);
  display: flex;
  justify-content: flex-end;
  gap: var(--space-2);
}

.mr-2 {
  margin-right: var(--space-2);
}

/* Animation */
.compose-container {
  animation: slideIn 0.3s ease-out;
}

@keyframes slideIn {
  from {
    opacity: 0;
    transform: translateY(30px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
</style>