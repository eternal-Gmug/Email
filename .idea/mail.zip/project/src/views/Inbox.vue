<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import EmailList from '../components/email/EmailList.vue'
import EmailFilter from '../components/email/EmailFilter.vue'
import { emails } from '../data/emails'

const router = useRouter()
const selectedFilter = ref('all')
const loading = ref(true)
const emailData = ref(emails)

const handleFilterChange = (filter: string) => {
  selectedFilter.value = filter
  
  // In a real app, you would fetch emails based on the filter
  // For now, we'll just simulate it
  loading.value = true
  
  setTimeout(() => {
    if (filter === 'unread') {
      emailData.value = emails.filter(email => !email.read)
    } else if (filter === 'starred') {
      emailData.value = emails.filter(email => email.starred)
    } else {
      emailData.value = emails
    }
    loading.value = false
  }, 500)
}

const handleEmailClick = (emailId: number) => {
  router.push(`/dashboard/email/${emailId}`)
}

onMounted(() => {
  // Simulate loading emails
  setTimeout(() => {
    loading.value = false
  }, 800)
})
</script>

<template>
  <div class="inbox-container">
    <div class="inbox-header">
      <h1>Inbox</h1>
      <EmailFilter
        :selected-filter="selectedFilter"
        @filter-change="handleFilterChange"
      />
    </div>
    
    <div v-if="loading" class="loading-container">
      <font-awesome-icon icon="spinner" spin class="loading-spinner" />
      <p>Loading your emails...</p>
    </div>
    
    <EmailList
      v-else
      :emails="emailData"
      @email-click="handleEmailClick"
    />
  </div>
</template>

<style scoped>
.inbox-container {
  background-color: white;
  border-radius: var(--border-radius-lg);
  box-shadow: var(--shadow);
  height: calc(100vh - 140px);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.inbox-header {
  padding: var(--space-4);
  border-bottom: 1px solid var(--color-gray-200);
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.inbox-header h1 {
  font-size: var(--text-xl);
  margin: 0;
  color: var(--color-gray-800);
}

.loading-container {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: var(--color-gray-500);
}

.loading-spinner {
  font-size: 2rem;
  margin-bottom: var(--space-4);
  color: var(--color-primary-500);
}
</style>