import { createApp } from 'vue'
import { createPinia } from 'pinia'
import { createRouter, createWebHistory } from 'vue-router'
import { library } from '@fortawesome/fontawesome-svg-core'
import { 
  faInbox, faEnvelope, faPaperPlane, faTrash, faStar, 
  faExclamationCircle, faSearch, faUser, faCog, faSignOutAlt,
  faReply, faReplyAll, faForward, faPaperclip, faSpinner,
  faCheck, faTimes, faPlus, faEdit, faSave, faChevronDown, 
  faChevronRight, faBars, faFile
} from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome'

import App from './App.vue'
import './styles/main.css'

// Import router views
import Login from './views/Login.vue'
import Register from './views/Register.vue'
import Dashboard from './views/Dashboard.vue'
import Inbox from './views/Inbox.vue'
import EmailView from './views/EmailView.vue'
import Compose from './views/Compose.vue'
import Settings from './views/Settings.vue'

// Add icons to the library
library.add(
  faInbox, faEnvelope, faPaperPlane, faTrash, faStar, 
  faExclamationCircle, faSearch, faUser, faCog, faSignOutAlt,
  faReply, faReplyAll, faForward, faPaperclip, faSpinner,
  faCheck, faTimes, faPlus, faEdit, faSave, faChevronDown,
  faChevronRight, faBars, faFile
)

// Create router
const routes = [
  { path: '/', redirect: '/login' },
  { path: '/login', component: Login },
  { path: '/register', component: Register },
  { 
    path: '/dashboard', 
    component: Dashboard,
    children: [
      { path: '', redirect: '/dashboard/inbox' },
      { path: 'inbox', component: Inbox },
      { path: 'email/:id', component: EmailView },
      { path: 'compose', component: Compose },
      { path: 'settings', component: Settings }
    ]
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

// Create app
const app = createApp(App)

app.use(createPinia())
app.use(router)
app.component('font-awesome-icon', FontAwesomeIcon)

app.mount('#app')