export interface Email {
  id: number;
  from: {
    name: string;
    email: string;
  };
  to: {
    name: string;
    email: string;
  }[];
  subject: string;
  body: string;
  date: string;
  read: boolean;
  starred: boolean;
  attachments: {
    name: string;
    size: string;
    type: string;
  }[];
}

export const emails: Email[] = [
  {
    id: 1,
    from: {
      name: 'GitHub',
      email: 'noreply@github.com'
    },
    to: [
      {
        name: 'John Doe',
        email: 'john.doe@example.com'
      }
    ],
    subject: 'Your repository has a new star!',
    body: `<p>Hello there,</p>
    <p>Great news! Someone has starred your repository <strong>vue-email-system</strong>. This brings your repository to a total of 42 stars.</p>
    <p>Keep up the good work!</p>
    <p>Best regards,<br>GitHub Team</p>`,
    date: '2025-01-10T09:42:31',
    read: false,
    starred: true,
    attachments: []
  },
  {
    id: 2,
    from: {
      name: 'Alice Johnson',
      email: 'alice.johnson@example.com'
    },
    to: [
      {
        name: 'John Doe',
        email: 'john.doe@example.com'
      }
    ],
    subject: 'Project Update - Q1 Report',
    body: `<p>Hi John,</p>
    <p>I've attached the Q1 report for your review. Please let me know if you have any questions or need any changes before the presentation next week.</p>
    <p>Highlights:</p>
    <ul>
      <li>Revenue increased by 15% compared to last quarter</li>
      <li>Customer satisfaction score improved to 4.8/5</li>
      <li>New feature adoption rate at 78%</li>
    </ul>
    <p>Thanks,<br>Alice</p>`,
    date: '2025-01-09T16:23:11',
    read: true,
    starred: false,
    attachments: [
      {
        name: 'Q1_Report_2025.pdf',
        size: '2.4 MB',
        type: 'application/pdf'
      },
      {
        name: 'Financial_Summary.xlsx',
        size: '1.2 MB',
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      }
    ]
  },
  {
    id: 3,
    from: {
      name: 'Marketing Team',
      email: 'marketing@example.com'
    },
    to: [
      {
        name: 'John Doe',
        email: 'john.doe@example.com'
      }
    ],
    subject: 'Social Media Campaign Draft',
    body: `<p>Hello John,</p>
    <p>We've prepared the draft for our upcoming social media campaign. The creative team has come up with several concepts that align with our brand guidelines and target audience preferences.</p>
    <p>We need your approval by Friday to meet the launch timeline.</p>
    <p>Regards,<br>Marketing Team</p>`,
    date: '2025-01-08T11:05:44',
    read: false,
    starred: false,
    attachments: [
      {
        name: 'Campaign_Draft_v2.pptx',
        size: '5.7 MB',
        type: 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
      }
    ]
  },
  {
    id: 4,
    from: {
      name: 'HR Department',
      email: 'hr@example.com'
    },
    to: [
      {
        name: 'All Employees',
        email: 'employees@example.com'
      }
    ],
    subject: 'Company Picnic - Save the Date',
    body: `<p>Dear Colleagues,</p>
    <p>We're excited to announce our annual company picnic will be held on Saturday, February 15, 2025, at Sunshine Park from 11:00 AM to 4:00 PM.</p>
    <p>Activities will include:</p>
    <ul>
      <li>Team building games</li>
      <li>BBQ lunch</li>
      <li>Family-friendly activities</li>
      <li>Awards ceremony</li>
    </ul>
    <p>Please RSVP by January 30th. We look forward to seeing everyone there!</p>
    <p>Best regards,<br>HR Department</p>`,
    date: '2025-01-07T09:15:22',
    read: true,
    starred: true,
    attachments: []
  },
  {
    id: 5,
    from: {
      name: 'Bob Smith',
      email: 'bob.smith@example.com'
    },
    to: [
      {
        name: 'John Doe',
        email: 'john.doe@example.com'
      }
    ],
    subject: 'Quick question about the API',
    body: `<p>Hey John,</p>
    <p>I'm having trouble with the authentication endpoint we discussed last week. The token seems to expire too quickly.</p>
    <p>Do you have a few minutes to jump on a call today?</p>
    <p>Thanks,<br>Bob</p>`,
    date: '2025-01-06T14:32:01',
    read: true,
    starred: false,
    attachments: []
  },
  {
    id: 6,
    from: {
      name: 'AWS Notifications',
      email: 'no-reply@aws.amazon.com'
    },
    to: [
      {
        name: 'John Doe',
        email: 'john.doe@example.com'
      }
    ],
    subject: 'Your AWS bill for December 2024',
    body: `<p>Hello,</p>
    <p>Your AWS bill for the period December 1-31, 2024 is now available.</p>
    <p>Total charges: $256.78</p>
    <p>You can view your detailed bill by logging into the AWS Management Console.</p>
    <p>Regards,<br>Amazon Web Services</p>`,
    date: '2025-01-05T08:00:15',
    read: false,
    starred: false,
    attachments: [
      {
        name: 'AWS_Invoice_Dec2024.pdf',
        size: '320 KB',
        type: 'application/pdf'
      }
    ]
  },
  {
    id: 7,
    from: {
      name: 'Sarah Williams',
      email: 'sarah.williams@example.com'
    },
    to: [
      {
        name: 'John Doe',
        email: 'john.doe@example.com'
      }
    ],
    subject: 'Design Review Meeting',
    body: `<p>Hi John,</p>
    <p>Let's schedule a design review meeting for the new product features. I've created some mockups that I'd like to get your feedback on.</p>
    <p>How does next Tuesday at 2 PM sound?</p>
    <p>Best,<br>Sarah</p>`,
    date: '2025-01-04T11:42:33',
    read: true,
    starred: true,
    attachments: []
  },
  {
    id: 8,
    from: {
      name: 'Spotify',
      email: 'info@spotify.com'
    },
    to: [
      {
        name: 'John Doe',
        email: 'john.doe@example.com'
      }
    ],
    subject: 'Your Weekly Mix is ready',
    body: `<p>Hi John,</p>
    <p>Your Weekly Mix is ready! We've curated a playlist of songs based on your recent listening habits.</p>
    <p>This week features new releases from your favorite artists and some tracks we think you'll love.</p>
    <p>Open Spotify to start listening!</p>
    <p>Enjoy,<br>The Spotify Team</p>`,
    date: '2025-01-03T10:00:00',
    read: true,
    starred: false,
    attachments: []
  }
];