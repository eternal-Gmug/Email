<script setup lang="ts">
const props = defineProps<{
  selectedFilter: string
}>()

const emit = defineEmits<{
  (e: 'filter-change', filter: string): void
}>()

const filters = [
  { id: 'all', label: 'All' },
  { id: 'unread', label: 'Unread' },
  { id: 'starred', label: 'Starred' }
]

const selectFilter = (filterId: string) => {
  emit('filter-change', filterId)
}
</script>

<template>
  <div class="email-filter">
    <button
      v-for="filter in filters"
      :key="filter.id"
      :class="['filter-btn', { active: selectedFilter === filter.id }]"
      @click="selectFilter(filter.id)"
    >
      {{ filter.label }}
    </button>
  </div>
</template>

<style scoped>
.email-filter {
  display: flex;
  gap: var(--space-2);
}

.filter-btn {
  background: none;
  border: none;
  padding: var(--space-1) var(--space-3);
  border-radius: var(--border-radius-lg);
  font-size: var(--text-sm);
  font-weight: 500;
  color: var(--color-gray-600);
  transition: all 0.2s;
  cursor: pointer;
}

.filter-btn:hover {
  background-color: var(--color-gray-100);
  color: var(--color-gray-900);
}

.filter-btn.active {
  background-color: var(--color-primary-100);
  color: var(--color-primary-700);
}
</style>