<script setup lang="ts">
import { computed } from 'vue'
import type { Email } from '../../data/emails'

const props = defineProps<{
  emails: Email[]
}>()

const emit = defineEmits<{
  (e: 'email-click', id: number): void
}>()

// Format date to a more readable format
const formatDate = (dateString: string): string => {
  const date = new Date(dateString)
  const now = new Date()
  
  // If the email is from today, show only the time
  if (date.toDateString() === now.toDateString()) {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  }
  
  // If the email is from this year, show the month and day
  if (date.getFullYear() === now.getFullYear()) {
    return date.toLocaleDateString([], { month: 'short', day: 'numeric' })
  }
  
  // Otherwise, show the full date
  return date.toLocaleDateString([], { year: 'numeric', month: 'short', day: 'numeric' })
}

// Truncate text to a certain length
const truncate = (text: string, length: number): string => {
  if (text.length <= length) return text
  return text.substring(0, length) + '...'
}

// Extract plain text from HTML
const stripHtml = (html: string): string => {
  const tmp = document.createElement('DIV')
  tmp.innerHTML = html
  return tmp.textContent || tmp.innerText || ''
}

const noEmailsMessage = computed(() => {
  return props.emails.length === 0 ? 'No emails found' : ''
})
</script>

<template>
  <div class="email-list-container">
    <div v-if="noEmailsMessage" class="no-emails">
      {{ noEmailsMessage }}
    </div>
    
    <div v-else class="email-list">
      <div 
        v-for="email in emails" 
        :key="email.id" 
        :class="['email-item', { 'unread': !email.read }]"
        @click="emit('email-click', email.id)"
      >
        <div class="email-sender">
          <div class="avatar">
            {{ email.from.name.charAt(0) }}
          </div>
        </div>
        
        <div class="email-content">
          <div class="email-header">
            <div class="email-from">{{ email.from.name }}</div>
            <div class="email-date">{{ formatDate(email.date) }}</div>
          </div>
          
          <div class="email-subject">
            <font-awesome-icon 
              v-if="email.starred" 
              icon="star" 
              class="star-icon"
            />
            {{ email.subject }}
          </div>
          
          <div class="email-preview">
            {{ truncate(stripHtml(email.body), 100) }}
            <span v-if="email.attachments.length > 0" class="attachment-indicator">
              <font-awesome-icon icon="paperclip" />
              {{ email.attachments.length }}
            </span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.email-list-container {
  flex: 1;
  overflow: auto;
}

.no-emails {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
  color: var(--color-gray-500);
  font-size: var(--text-lg);
}

.email-list {
  display: flex;
  flex-direction: column;
}

.email-item {
  display: flex;
  padding: var(--space-3) var(--space-4);
  border-bottom: 1px solid var(--color-gray-200);
  cursor: pointer;
  transition: background-color 0.2s;
}

.email-item:hover {
  background-color: var(--color-gray-100);
}

.email-item.unread {
  background-color: var(--color-primary-50);
}

.email-item.unread:hover {
  background-color: var(--color-primary-100);
}

.email-sender {
  margin-right: var(--space-3);
}

.avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background-color: var(--color-primary-100);
  color: var(--color-primary-700);
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 600;
}

.email-content {
  flex: 1;
  min-width: 0; /* Important for text truncation */
}

.email-header {
  display: flex;
  justify-content: space-between;
  margin-bottom: var(--space-1);
}

.email-from {
  font-weight: 600;
  color: var(--color-gray-900);
}

.email-item.unread .email-from {
  font-weight: 700;
}

.email-date {
  color: var(--color-gray-500);
  font-size: var(--text-sm);
}

.email-subject {
  font-weight: 500;
  margin-bottom: var(--space-1);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  display: flex;
  align-items: center;
  gap: var(--space-2);
}

.star-icon {
  color: var(--color-warning-500);
}

.email-preview {
  color: var(--color-gray-600);
  font-size: var(--text-sm);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  display: flex;
  justify-content: space-between;
}

.attachment-indicator {
  color: var(--color-gray-500);
  white-space: nowrap;
  margin-left: var(--space-2);
}

/* Animation */
.email-item {
  animation: fadeIn 0.3s ease-out;
  animation-fill-mode: both;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* Apply cascading delay to list items */
.email-item:nth-child(1) { animation-delay: 0.05s; }
.email-item:nth-child(2) { animation-delay: 0.1s; }
.email-item:nth-child(3) { animation-delay: 0.15s; }
.email-item:nth-child(4) { animation-delay: 0.2s; }
.email-item:nth-child(5) { animation-delay: 0.25s; }
.email-item:nth-child(6) { animation-delay: 0.3s; }
.email-item:nth-child(7) { animation-delay: 0.35s; }
.email-item:nth-child(8) { animation-delay: 0.4s; }
</style>