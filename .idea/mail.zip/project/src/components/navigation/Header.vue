<script setup lang="ts">
import { ref } from 'vue'

defineEmits(['toggle-sidebar'])

const searchQuery = ref('')

const performSearch = () => {
  // Implement search functionality
  console.log('Searching for:', searchQuery.value)
}
</script>

<template>
  <header class="app-header">
    <div class="header-left">
      <button class="menu-toggle" @click="$emit('toggle-sidebar')">
        <font-awesome-icon icon="bars" />
      </button>
      
      <div class="search-bar">
        <font-awesome-icon icon="search" class="search-icon" />
        <input
          v-model="searchQuery"
          type="text"
          placeholder="Search mail..."
          @keyup.enter="performSearch"
        />
      </div>
    </div>
    
    <div class="header-right">
      <div class="user-profile">
        <div class="avatar">
          <font-awesome-icon icon="user" />
        </div>
        <span class="username hidden-sm">John Doe</span>
      </div>
    </div>
  </header>
</template>

<style scoped>
.app-header {
  height: 60px;
  background-color: white;
  border-bottom: 1px solid var(--color-gray-200);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 var(--space-4);
}

.header-left {
  display: flex;
  align-items: center;
  gap: var(--space-4);
}

.menu-toggle {
  background: none;
  border: none;
  color: var(--color-gray-600);
  font-size: var(--text-lg);
  cursor: pointer;
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  transition: background-color 0.2s;
}

.menu-toggle:hover {
  background-color: var(--color-gray-100);
  color: var(--color-gray-900);
}

.search-bar {
  position: relative;
  width: 300px;
}

.search-icon {
  position: absolute;
  left: var(--space-3);
  top: 50%;
  transform: translateY(-50%);
  color: var(--color-gray-500);
}

.search-bar input {
  width: 100%;
  padding: var(--space-2) var(--space-2) var(--space-2) var(--space-8);
  border-radius: var(--border-radius-lg);
  border: 1px solid var(--color-gray-300);
  background-color: var(--color-gray-100);
  font-size: var(--text-sm);
  transition: all 0.2s;
}

.search-bar input:focus {
  outline: none;
  border-color: var(--color-primary-500);
  background-color: white;
  box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.1);
}

.header-right {
  display: flex;
  align-items: center;
  gap: var(--space-4);
}

.user-profile {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  cursor: pointer;
}

.avatar {
  width: 32px;
  height: 32px;
  background-color: var(--color-primary-100);
  color: var(--color-primary-700);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.username {
  font-weight: 500;
  color: var(--color-gray-700);
}

@media (max-width: 640px) {
  .search-bar {
    width: 200px;
  }
}

@media (max-width: 480px) {
  .search-bar {
    width: 150px;
  }
}
</style>