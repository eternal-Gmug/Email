<script setup lang="ts">
import { computed } from 'vue'
import { useRouter, useRoute } from 'vue-router'

const props = defineProps<{
  isOpen: boolean
}>()

const router = useRouter()
const route = useRoute()

const sidebarClass = computed(() => {
  return {
    'sidebar': true,
    'sidebar-closed': !props.isOpen
  }
})

const isActive = (path: string) => {
  return route.path.includes(path)
}

const navigateTo = (path: string) => {
  router.push(path)
}
</script>

<template>
  <aside :class="sidebarClass">
    <div class="sidebar-header">
      <div class="logo">
        <font-awesome-icon icon="envelope" class="logo-icon" />
        <span class="logo-text" v-if="isOpen">Vue Mail</span>
      </div>
    </div>
    
    <div class="sidebar-content">
      <button 
        class="compose-btn" 
        @click="navigateTo('/dashboard/compose')"
      >
        <font-awesome-icon icon="plus" />
        <span v-if="isOpen">写邮件</span>
      </button>
      
      <nav class="sidebar-nav">
        <a 
          href="#" 
          :class="['sidebar-link', { active: isActive('/dashboard/inbox') }]"
          @click.prevent="navigateTo('/dashboard/inbox')"
        >
          <font-awesome-icon icon="inbox" class="sidebar-icon" />
          <span v-if="isOpen">收件箱</span>
          <span v-if="isOpen" class="badge">24</span>
        </a>
        
        <a 
          href="#" 
          :class="['sidebar-link', { active: route.path === '/dashboard/sent' }]"
          @click.prevent="navigateTo('/dashboard/sent')"
        >
          <font-awesome-icon icon="paper-plane" class="sidebar-icon" />
          <span v-if="isOpen">已发送</span>
        </a>
        
        <a 
          href="#" 
          :class="['sidebar-link', { active: route.path === '/dashboard/starred' }]"
          @click.prevent="navigateTo('/dashboard/starred')"
        >
          <font-awesome-icon icon="star" class="sidebar-icon" />
          <span v-if="isOpen">已加星标</span>
        </a>
        
        <a 
          href="#" 
          :class="['sidebar-link', { active: route.path === '/dashboard/important' }]"
          @click.prevent="navigateTo('/dashboard/important')"
        >
          <font-awesome-icon icon="exclamation-circle" class="sidebar-icon" />
          <span v-if="isOpen">重要</span>
        </a>
        
        <a 
          href="#" 
          :class="['sidebar-link', { active: route.path === '/dashboard/trash' }]"
          @click.prevent="navigateTo('/dashboard/trash')"
        >
          <font-awesome-icon icon="trash" class="sidebar-icon" />
          <span v-if="isOpen">垃圾箱</span>
        </a>
      </nav>
    </div>
    
    <div class="sidebar-footer">
      <a 
        href="#" 
        :class="['sidebar-link', { active: route.path === '/dashboard/settings' }]"
        @click.prevent="navigateTo('/dashboard/settings')"
      >
        <font-awesome-icon icon="cog" class="sidebar-icon" />
        <span v-if="isOpen">设置</span>
      </a>
      
      <a 
        href="#" 
        class="sidebar-link"
        @click.prevent="navigateTo('/login')"
      >
        <font-awesome-icon icon="sign-out-alt" class="sidebar-icon" />
        <span v-if="isOpen">退出</span>
      </a>
    </div>
  </aside>
</template>

<style scoped>
.sidebar {
  width: 240px;
  height: 100vh;
  background-color: white;
  border-right: 1px solid var(--color-gray-200);
  display: flex;
  flex-direction: column;
  transition: width 0.3s ease;
  z-index: 10;
}

.sidebar-closed {
  width: 60px;
}

.sidebar-header {
  padding: var(--space-4);
  border-bottom: 1px solid var(--color-gray-200);
}

.logo {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  color: var(--color-primary-600);
}

.logo-icon {
  font-size: 1.5rem;
}

.logo-text {
  font-weight: 700;
  font-size: 1.25rem;
}

.sidebar-content {
  flex: 1;
  overflow-y: auto;
  padding: var(--space-4) var(--space-2);
}

.compose-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-2);
  background-color: var(--color-primary-600);
  color: white;
  border: none;
  border-radius: var(--border-radius-lg);
  padding: var(--space-3) var(--space-4);
  font-weight: 600;
  margin-bottom: var(--space-4);
  width: 100%;
  transition: background-color 0.2s;
}

.compose-btn:hover {
  background-color: var(--color-primary-700);
}

.sidebar-nav {
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
}

.sidebar-link {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  padding: var(--space-2) var(--space-3);
  border-radius: var(--border-radius);
  color: var(--color-gray-700);
  text-decoration: none;
  transition: background-color 0.2s;
  white-space: nowrap;
}

.sidebar-link:hover {
  background-color: var(--color-gray-100);
  color: var(--color-gray-900);
}

.sidebar-link.active {
  background-color: var(--color-primary-50);
  color: var(--color-primary-700);
  font-weight: 500;
}

.sidebar-icon {
  width: 20px;
  text-align: center;
}

.badge {
  margin-left: auto;
  background-color: var(--color-primary-600);
  color: white;
  border-radius: 12px;
  padding: 2px 8px;
  font-size: var(--text-xs);
  font-weight: 600;
}

.sidebar-footer {
  padding: var(--space-4) var(--space-2);
  border-top: 1px solid var(--color-gray-200);
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
}

@media (max-width: 768px) {
  .sidebar {
    position: absolute;
    left: 0;
    top: 0;
    transform: translateX(-100%);
  }
  
  .sidebar.sidebar-open {
    transform: translateX(0);
  }
}
</style>