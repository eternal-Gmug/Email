<script setup lang="ts">
// Main app component
</script>

<template>
  <div class="app-container">
    <router-view />
  </div>
</template>

<style>
.app-container {
  min-height: 100vh;
  width: 100%;
}
</style>